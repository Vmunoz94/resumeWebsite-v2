How To Play Agar.io!!!

*Important - The following ports will be used by Default: 
	redis - 6379
	mongoDB - 27017
	gateway - 4000
	frontend - 3000
	userauth - 5000
	websocket - 6000
* these ports can be changed in the docker-compose file. For example, you can map different local computer ports to the necessary docker container ports. "4000:4000", left side of ":" corresponds to your local ports; however, the right side correspond to the docker container's port and must NOT be changed. 


Assuming you have Docker already installed,
To start the APP:
1st.  Open the terminal and navigate to where you have saved the downloaded file
2nd.  Start a docker swarm -> 'Docker swarm init'
3rd.  Run the docker compose file -> 'Docker stack deploy -c docker-compose.yml agario-clone'

This should start the stack
Now go to localhost:4000 in your preferred web browser
May take awhile for the frontend to load initially
Enjoy :)


To shutdown the app:
1st.  run -> 'Docker stack remove agario-clone'
2nd.  leave the swarm -> 'Docker swarm leave --force'

